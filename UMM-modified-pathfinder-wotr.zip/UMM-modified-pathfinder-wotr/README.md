# UnityModManager changed files for Pathfinder Wrath of the Righteous for MacOS

We get this files by applying the Assembly option in Windows. This was done with the following versions

- Pathfinder WotR game version: `1.0.1c`
- UnityModManager version: `0.23.5b`

## Download and unzip

Download and unzip the `UMM-modified-pathfinder-wotr.zip` file. For the rest of this README, we'll assume that the contents are now in the `~/Downloads/UMM-modified-pathfinder-wotr/` folder.

## In Steam

The base folder, unless otherwise specified, will be `~/Library/Application\ Support/Steam/steamapps/common/Pathfinder\ Second\ Adventure/`

In that base folder, we need to create a new `Mods` folder. This is where we need to unzip the different mods that we download, like [Toy Box](https://www.nexusmods.com/pathfinderwrathoftherighteous/mods/8)

```sh
mkdir ~/Library/Application\ Support/Steam/steamapps/common/Pathfinder\ Second\ Adventure/Mods
```

After that, we need to add the UnitedModManager folder into the app.

```sh
cp -a ~/Downloads/UMM-modified-pathfinder-wotr/Unity* ~/Library/Application\ Support/Steam/steamapps/common/Pathfinder\ Second\ Adventure/Wrath.app/Contents/Resources/Data/Managed
```

This will copy:

- the UnityModManager folder
- `UnityEngine.UIModule.dll` (replace with the one that is there)
- `UnityEngine.UIModule.dll.original_` (backup from the original)

When asked if you want to replace files, say yes.

## How?

I followed the same procedure of https://github.com/ThyWoof/UMM-MAC-PathFinderKingMaker by applying UnityModManager in windows and checking the changed files.
